class Queue:
    "Docstring"
    q: str
