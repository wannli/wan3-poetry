from .sandbox import Queue

q = Queue()
