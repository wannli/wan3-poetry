# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['wan3']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'wan3',
    'version': '2.1.0',
    'description': '',
    'long_description': None,
    'author': 'Wannes Lint',
    'author_email': 'contact@wanneslint.net',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
